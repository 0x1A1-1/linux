# WACM
WACM (Women in CS) Intermediare Linux stuff
