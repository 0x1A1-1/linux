fun() {
	for() 
	{ 
		for() 
		{
			if()
			{ 
			}
		}
	}
}

